from django.contrib import admin
from .models import Todolist

admin.site.register(Todolist)



# Register your models here.
